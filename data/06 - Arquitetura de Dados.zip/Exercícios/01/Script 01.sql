select cd_func, nm_func, vl_salario 
       from loc_funcionario;

select nm_func, cd_depto, vl_perc_comissao, dt_inicio 
       from loc_funcionario
       order by nm_func;

select nm_func "NOME",
      	 cd_depto "DEPARTAMENTO",
      	 vl_salario "SALARIO",
      	 vl_perc_comissao "COMISS�O",
      	 dt_inicio "INICIO"
      	 from loc_funcionario
      	 where mod(cd_func, 2) = 0
       order by cd_func desc;

select nm_func "NOME",
      	 cd_depto "DEPARTAMENTO",
       vl_salario "SALARIO",
       vl_perc_comissao "COMISS�O",
       dt_inicio "INICIO"
       from loc_funcionario
       where mod(cd_func, 2) = 1
       order by vl_salario desc;

select nm_cargo "CARGO",
      	 vl_salario "SALARIO"
       from loc_funcionario
       order by CARGO;

select nm_cliente "NOME",
       tp_cliente "TIPO",
       nr_estrelas "N� ESTRELAS",
       telefone "TELEFONE",
       fax "FAX" 
       from loc_cliente
       where nr_estrelas >= &num_estrelas;

select count(*), nr_estrelas 
       from loc_cliente
       group by nr_estrelas
       having count(*) > 10;

select nm_cliente "NOME",
       tp_cliente "TIPO",
       nr_estrelas "N� ESTRELAS",
       telefone "TELEFONE",
       fax "FAX" 
       from loc_cliente
       where nm_cliente like '%&letra%'
       order by nm_cliente;

select  cd_func "CODIGO FUNCIONARIO",
        nm_func "NOME",
        vl_salario "SALARIO",
        cd_depto "CODIGO DEPARTAMENTO"
        from loc_funcionario
        where cd_depto = &cd1
        or    cd_depto = &cd2;

select  cd_func "CODIGO FUNCIONARIO",
        nm_func "NOME",
        vl_salario "SALARIO",
        vl_salario*6 "SALARIO SEMESTRAL",
        vl_salario*12 "SALARIO ANUAL",
        cd_depto "CODIGO DEPARTAMENTO"
        from loc_funcionario
        where cd_depto = &cd1;

select min(MENOR.Valor) "MENOR VALOR"
      from (select &num1 as Valor
            from dual
            union
            select &num2 as Valor
            from dual
            union
            select &num3 as Valor 
      from dual) MENOR;

select concat('&nome', ' &sobrenome') "NOME COMPLETO"
       from dual;

select TO_CHAR(TO_DATE('&hoje'), 'fmMONTH') TESTE_DATA
       from dual;

select ('Quem nasceu no dia '||TO_CHAR(TO_DATE('01/12/1978'), 'fmDD Month YYYY')||' t�m '||TO_CHAR(sysdate-TO_DATE('01/12/1978'), 99999)||' dias de vida') TESTE_DATA
       from dual;

select nr_pedido "N�MERO PEDIDO",
       cd_cliente "C�DIGO CLIENTE" 
       from loc_pedido_locacao
       where dt_retirada > dt_entrega;

select nr_item "N�MERO ITEM",
       nr_pedido "N�MERO PEDIDO"
       from loc_item_locacao
       where dt_retirada > dt_entrega;

select loc_cliente.nm_cliente
       from loc_cliente 
       inner join loc_cli_fisica
       on loc_cliente.cd_cliente = loc_cli_fisica.cd_cliente
       where dt_nascimento > sysdate;

select loc_cliente.nm_cliente, loc_cliente.cd_cliente
       from loc_cliente 
       inner join loc_cli_fisica
       on loc_cliente.cd_cliente = loc_cli_fisica.cd_cliente
       where (sysdate - dt_nascimento)/365 < 18;

select nr_pedido "N�MERO PEDIDO",
       cd_cliente "C�DIGO CLIENTE"
       from loc_pedido_locacao
       where dt_locacao > dt_entrega
       or    dt_locacao > dt_retirada;

select nr_pedido "N�MERO PEDIDO",
       cd_cliente "C�DIGO CLIENTE"
       from loc_pedido_locacao
       where dt_locacao > dt_entrega
       or    dt_locacao > dt_retirada
       or    vl_total <= 0;

select nr_pedido "N�MERO PEDIDO",
       cd_cliente "C�DIGO CLIENTE"
       from loc_pedido_locacao
       where dt_locacao > dt_entrega
       or    dt_locacao > dt_retirada
       or    vl_total <= 0;

select * from loc_cliente
         where nm_cliente like '__A%';

select * from loc_cliente
         where nm_cliente like '%A';

select * from loc_cliente
         where nm_cliente like '%O';

select * from loc_cliente
         where (nm_cliente like '%I%'
         or    nm_cliente like '%i%')
         and nr_estrelas < 4;


